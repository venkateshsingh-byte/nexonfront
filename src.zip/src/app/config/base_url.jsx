const BASE_URL = process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:4000/api/v1';
//const BASE_URL = process.env.NEXT_PUBLIC_BASE_URL || 'https://nexonapi.onrender.com/api/v1';
export default BASE_URL;