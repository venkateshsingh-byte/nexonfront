import Index from "./Index";

export default function Home() {
	
	return (
		<Index></Index>
	);
}
